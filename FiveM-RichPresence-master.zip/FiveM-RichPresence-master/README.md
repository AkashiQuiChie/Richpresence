# FiveM-RichPresence
Simple resource that uses Discord's rich presence to display street name, vehicle and more
