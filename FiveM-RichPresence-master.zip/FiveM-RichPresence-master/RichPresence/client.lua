local WaitTime = 2500 -- How often do you want to update the status (In MS)
	
Citizen.CreateThread(function()
  while true do
  #Ceci est l'ID de l'application (remplacez-le par votre propre)
  SetDiscordAppId(742825869906804786)

  #Ici, vous devrez mettre le nom de l'image pour l'icône "Large".
  SetDiscordRichPresenceAsset('logo')
      
  #Ici, vous pouvez ajouter un texte de survol pour l'icône "Large".                                                                                                                                                                                            
  SetDiscordRichPresenceAssetText('Bryce City RP')
     
  #Ici, vous devrez mettre le nom de l'image pour l'icône "small".
  SetDiscordRichPresenceAssetSmall('logo')

  #Ici, vous pouvez ajouter un texte de survol pour l'icône "small".                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
  SetDiscordRichPresenceAssetSmallText('Bryce City')
  
  #Merci à @bengold  pour le code du 64 slots
  #Pour afficher le nombre de joueurs sur 64 il faut ajouter ceci :
  players = {}
  for i = 0, 255 do
      if NetworkIsPlayerActive( i ) then
          table.insert( players, i )
      end
  end
  SetRichPresence(GetPlayerName(PlayerId()) .. " - ".. #players .. "/64")

  Citizen.Wait(60000)
  end
end)
		local x,y,z = table.unpack(GetEntityCoords(PlayerPedId(),true))
		local StreetHash = GetStreetNameAtCoord(x, y, z)
		Citizen.Wait(WaitTime)
		if StreetHash ~= nil then
			StreetName = GetStreetNameFromHashKey(StreetHash)
			if IsPedOnFoot(PlayerPedId()) and not IsEntityInWater(PlayerPedId()) then
				if IsPedSprinting(PlayerPedId()) then
					SetRichPresence("Cours Vers "..StreetName)
				elseif IsPedRunning(PlayerPedId()) then
					SetRichPresence("S'épuise Vers "..StreetName)
				elseif IsPedWalking(PlayerPedId()) then
					SetRichPresence("Marche Vers "..StreetName)
				elseif IsPedStill(PlayerPedId()) then
					SetRichPresence("Est Debout Sur "..StreetName)
				end
			elseif GetVehiclePedIsUsing(PlayerPedId()) ~= nil and not IsPedInAnyHeli(PlayerPedId()) and not IsPedInAnyPlane(PlayerPedId()) and not IsPedOnFoot(PlayerPedId()) and not IsPedInAnySub(PlayerPedId()) and not IsPedInAnyBoat(PlayerPedId()) then
				local VehSpeed = GetEntitySpeed(GetVehiclePedIsUsing(PlayerPedId()))
				local CurSpeed = UseKMH and math.ceil(VehSpeed * 3.6) or math.ceil(VehSpeed * 2.236936)
				local VehName = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsUsing(PlayerPedId()))))
				if CurSpeed > 50 then
					SetRichPresence("Speeding down "..StreetName.." In a "..VehName)
				elseif CurSpeed <= 50 and CurSpeed > 0 then
					SetRichPresence("Cruising down "..StreetName.." In a "..VehName)
				elseif CurSpeed == 0 then
					SetRichPresence("Parked on "..StreetName.." In a "..VehName)
				end
			elseif IsPedInAnyHeli(PlayerPedId()) or IsPedInAnyPlane(PlayerPedId()) then
				local VehName = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsUsing(PlayerPedId()))))
				if IsEntityInAir(GetVehiclePedIsUsing(PlayerPedId())) or GetEntityHeightAboveGround(GetVehiclePedIsUsing(PlayerPedId())) > 5.0 then
					SetRichPresence("Flying over "..StreetName.." in a "..VehName)
				else
					SetRichPresence("Landed at "..StreetName.." in a "..VehName)
				end
			elseif IsEntityInWater(PlayerPedId()) then
				SetRichPresence("Swimming around")
			elseif IsPedInAnyBoat(PlayerPedId()) and IsEntityInWater(GetVehiclePedIsUsing(PlayerPedId())) then
				local VehName = GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsUsing(PlayerPedId()))))
				SetRichPresence("Sailing around in a "..VehName)
			elseif IsPedInAnySub(PlayerPedId()) and IsEntityInWater(GetVehiclePedIsUsing(PlayerPedId())) then
				SetRichPresence("In a yellow submarine")
			end
		end
	end
end)
